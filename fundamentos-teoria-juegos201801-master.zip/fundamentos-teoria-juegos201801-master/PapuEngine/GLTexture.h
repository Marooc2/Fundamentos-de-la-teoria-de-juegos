#pragma once

#include <GL/glew.h>

struct GLTexture {
	GLuint id;
	float width;
	float height;
};
