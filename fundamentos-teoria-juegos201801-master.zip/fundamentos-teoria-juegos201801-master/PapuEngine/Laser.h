#pragma once
class Laser
{
public:
	Laser();
	~Laser();
};

