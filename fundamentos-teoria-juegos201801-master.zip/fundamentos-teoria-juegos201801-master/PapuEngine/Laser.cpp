#include "Laser.h"



Laser::Laser()
{
}


Laser::~Laser()
{
}
