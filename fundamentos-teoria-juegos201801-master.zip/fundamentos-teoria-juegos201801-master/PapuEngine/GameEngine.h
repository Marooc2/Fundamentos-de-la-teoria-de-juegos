#pragma once
namespace MyEngine {
	extern int init();
}
