#include "GameScreen.h"



GameScreen::GameScreen(Window* window) :_window(window){
}

void GameScreen::build() {

}
void GameScreen::destroy() {

}
void GameScreen::onExit() {

}
void GameScreen::onEntry() {

}
void GameScreen::draw() {

}
void GameScreen::update() {

}
void GameScreen::initSystem() {

}


int GameScreen::getNextScreen() const {
	return -1;
}
int GameScreen::getPrevScreen() const {
	return 0;
}
void GameScreen::checkInput() {

}
 


GameScreen::~GameScreen()
{
}
